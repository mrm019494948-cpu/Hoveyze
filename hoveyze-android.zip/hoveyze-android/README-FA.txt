ساخت APK آنلاین با GitHub (رایگان)
1) در github.com وارد شوید و یک Repository جدید بسازید (مثلاً hoveyze-android).
2) تمام فایل‌های همین پوشه را داخل آن آپلود کنید، حتماً پوشه‌ی مخفی .github هم باشد.
   (اگر با مرورگر آپلود می‌کنید و .github نرفت: Add file > Create new file و در نام فایل
   بنویسید  .github/workflows/build.yml  و محتوای آن فایل را paste کنید.)
3) به تب Actions بروید > Build APK > Run workflow.
4) بعد از حدود ۳ تا ۵ دقیقه، داخل همان اجرا در بخش Artifacts فایل Hoveyze-APK را دانلود و unzip کنید.
5) فایل app-debug.apk را روی گوشی نصب کنید (نصب از منبع ناشناس را فعال کنید).
تغییر آدرس سرور: فایل app/src/main/java/ir/hoveyze/app/MainActivity.java (HOST و URL).
